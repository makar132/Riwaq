import { useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { FiMenu, FiX } from "react-icons/fi";
import { useAuth } from "../auth/useAuth";
import * as authSvc from "../services/auth";

export default function Navbar() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleMenu = () => setMenuOpen((v) => !v);
  const closeMenu = () => setMenuOpen(false);

  const handleLogout = async () => {
    await authSvc.logout();
    closeMenu();
    navigate("/", { replace: true });
  };

  const links = [
    { label: "Home", path: "/" },
    { label: "Courses", path: "/courses" },
    { label: "Careers", path: "/careers" },
    { label: "Blog", path: "/blog" },
    { label: "About Us", path: "/about" },
  ];

  const initials = (
    user?.name?.trim()?.charAt(0) ||
    user?.email?.trim()?.charAt(0) ||
    "U"
  ).toUpperCase();

  return (
    <header className="fixed inset-x-0 top-0 z-50 h-16 w-full bg-[#49BBBD] text-white shadow-sm">
      <nav className="mx-auto flex h-full max-w-7xl items-center justify-between px-4">
        {/* Logo */}
        <NavLink
          to="/"
          onClick={closeMenu}
          className="text-3xl font-extrabold tracking-tight"
        >
          <span className="rounded-md bg-white px-2 py-1 text-[#49BBBD]">
            TOTC
          </span>
        </NavLink>

        {/* Desktop nav */}
        <div className="hidden md:flex md:items-center md:gap-6">
          {links.map(({ label, path }) => (
            <NavLink
              key={path}
              to={path}
              onClick={closeMenu}
              className={({ isActive }) =>
                `group relative inline-block px-1 py-0.5 text-[15px] font-medium transition ${isActive ? "text-white after:scale-x-100" : "text-white/85 after:scale-x-0 hover:text-white"} after:absolute after:-bottom-0.5 after:left-0 after:h-[2px] after:w-full after:origin-left after:bg-white after:transition-transform after:duration-300`
              }
            >
              {label}
            </NavLink>
          ))}
          {user?.isAdmin && (
            <NavLink
              to="/admin"
              className={({ isActive }) =>
                `group relative inline-block px-1 py-0.5 text-[15px] font-medium transition ${isActive ? "text-white after:scale-x-100" : "text-white/85 after:scale-x-0 hover:text-white"} after:absolute after:-bottom-0.5 after:left-0 after:h-[2px] after:w-full after:origin-left after:bg-white after:transition-transform after:duration-300`
              }
            >
              Admin
            </NavLink>
          )}

          {!user ? (
            <div className="flex items-center gap-3">
              <NavLink
                to="/login"
                onClick={closeMenu}
                className={({ isActive }) =>
                  `rounded-full px-4 py-2 text-sm font-semibold transition hover:opacity-90 ${isActive ? "bg-white text-[#49BBBD]" : "bg-white/20 text-white backdrop-blur-md"}`
                }
              >
                Login
              </NavLink>
              <NavLink
                to="/register"
                onClick={closeMenu}
                className={({ isActive }) =>
                  `rounded-full px-4 py-2 text-sm font-semibold transition hover:opacity-90 ${isActive ? "bg-white text-[#49BBBD]" : "bg-white/20 text-white backdrop-blur-md"}`
                }
              >
                Sign Up
              </NavLink>
            </div>
          ) : (
            <div className="flex items-center gap-4">
              {user.isAdmin && (
                <NavLink
                  to="/dashboard"
                  onClick={closeMenu}
                  className={({ isActive }) =>
                    `group relative inline-block px-1 py-0.5 text-[15px] font-medium transition ${isActive ? "text-white after:scale-x-100" : "text-white/85 after:scale-x-0 hover:text-white"} after:absolute after:-bottom-0.5 after:left-0 after:h-[2px] after:w-full after:origin-left after:bg-white after:transition-transform after:duration-300`
                  }
                >
                  Dashboard
                </NavLink>
              )}

              {/* user chip */}
              <div className="flex items-center gap-2">
                <div className="grid h-8 w-8 place-items-center rounded-full bg-white/25 text-sm font-bold">
                  {initials}
                </div>
                <span className="hidden text-sm text-white/90 lg:inline">
                  {user.name || user.email}
                </span>
              </div>

              <button
                onClick={handleLogout}
                className="text-sm font-semibold text-white/90 hover:text-white"
              >
                Logout
              </button>
            </div>
          )}
        </div>

        {/* Mobile hamburger */}
        <button
          onClick={toggleMenu}
          className="text-2xl text-white focus:outline-none md:hidden"
          aria-label="Toggle menu"
          aria-expanded={menuOpen}
        >
          {menuOpen ? <FiX /> : <FiMenu />}
        </button>
      </nav>

      {/* Mobile drawer */}
      <div
        className={`transition-all duration-300 ease-in-out md:hidden ${
          menuOpen ? "max-h-[80vh] opacity-100" : "max-h-0 opacity-0"
        } overflow-hidden border-t border-white/10 bg-[#49BBBD]`}
      >
        <div className="flex flex-col gap-4 p-4">
          {links.map(({ label, path }) => (
            <NavLink
              key={path}
              to={path}
              onClick={closeMenu}
              className={({ isActive }) =>
                `block rounded px-2 py-2 text-base font-medium transition ${isActive ? "bg-white text-[#49BBBD]" : "text-white/90 hover:bg-white/10"}`
              }
            >
              {label}
            </NavLink>
          ))}

          {!user ? (
            <div className="mt-2 grid grid-cols-2 gap-3">
              <NavLink
                to="/login"
                onClick={closeMenu}
                className="rounded-full bg-white/20 px-4 py-2 text-center text-sm font-semibold text-white hover:opacity-90"
              >
                Login
              </NavLink>
              <NavLink
                to="/register"
                onClick={closeMenu}
                className="rounded-full bg-white px-4 py-2 text-center text-sm font-semibold text-[#49BBBD] hover:bg-white/95"
              >
                Sign Up
              </NavLink>
            </div>
          ) : (
            <>
              {user.isAdmin && (
                <NavLink
                  to="/dashboard"
                  onClick={closeMenu}
                  className="block rounded px-2 py-2 text-base font-medium text-white/90 hover:bg-white/10"
                >
                  Dashboard
                </NavLink>
              )}

              <div className="mt-2 flex items-center gap-2 rounded bg-white/10 p-2">
                <div className="grid h-8 w-8 place-items-center rounded-full bg-white/25 text-sm font-bold">
                  {initials}
                </div>
                <span className="text-sm">{user.name || user.email}</span>
              </div>

              <button
                onClick={handleLogout}
                className="mt-2 rounded px-2 py-2 text-left text-base font-semibold text-white/90 hover:bg-white/10"
              >
                Logout
              </button>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
