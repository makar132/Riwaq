import React, { useState } from "react";
import { useCourses } from "../hooks/useCourses";
import { usePagination } from "../hooks/usePagination";
import {
  useAddCourse,
  useUpdateCourse,
  useDeleteCourse,
} from "../hooks/useCoursesMutations";
import Modal from "./Modal";

export default function CourseTable() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentCourse, setCurrentCourse] = useState(null);

  const { data: courses, isLoading, isError } = useCourses();
  const { paginatedData, currentPage, totalPages, setPage } = usePagination(
     courses || [],
    1
  );

  // CRUD mutations
  const { mutate: addCourse } = useAddCourse();
  const { mutate: updateCourse } = useUpdateCourse();
  const { mutate: deleteCourse } = useDeleteCourse();

  const openAddModal = () => {
    setCurrentCourse(null);
    setIsModalOpen(true);
  };

  const openUpdateModal = (course) => {
    setCurrentCourse(course);
    setIsModalOpen(true);
  };

  const handleSave = (values) => {
    if (currentCourse) {
      updateCourse({ id: currentCourse.id, updatedFields: values });
    } else {
      addCourse({ ...values, createdAt: new Date() });
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this course?")) {
      deleteCourse(id);
    }
  };

  if (isLoading) return <div>Loading courses...</div>;
  if (isError) return <div>Error fetching courses.</div>;

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-2xl font-bold">Course Management</h1>
        <button
          onClick={openAddModal}
          className="rounded bg-blue-500 px-4 py-2 text-white"
        >
          Add New Course
        </button>
      </div>

      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left">Title</th>
            <th className="px-6 py-3 text-left">Instructor</th>
            <th className="px-6 py-3 text-right">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200 bg-white">
          {paginatedData.map((course) => (
            <tr key={course.id}>
              <td className="px-6 py-4">{course.title}</td>
              <td className="px-6 py-4">{course.instructor}</td>
              <td className="px-6 py-4 text-right">
                <button
                  onClick={() => openUpdateModal(course)}
                  className="mr-2 text-indigo-600 hover:text-indigo-900"
                >
                  Edit
                </button>
                <button
                  onClick={() => handleDelete(course.id)}
                  className="text-red-600 hover:text-red-900"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Pagination Controls */}
      <div className="mt-4 flex justify-center space-x-2">
        <button
          onClick={() => setPage(currentPage - 1)}
          disabled={currentPage === 1}
          className="rounded border px-3 py-1"
        >
          Previous
        </button>
        <span className="px-3 py-1">
          Page {currentPage} of {totalPages}
        </span>
        <button
          onClick={() => setPage(currentPage + 1)}
          disabled={currentPage === totalPages}
          className="rounded border px-3 py-1"
        >
          Next
        </button>
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        course={currentCourse}
        onSave={handleSave}
      />
    </div>
  );
}
