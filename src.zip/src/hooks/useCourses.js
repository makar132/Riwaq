// import { collection, onSnapshot, query, orderBy } from "firebase/firestore";
// import { db } from "../firebase"; // Your Firebase config file
// import { useQuery } from "@tanstack/react-query";

// const COURSES_QUERY_KEY = "courses";

// export function useCourses() {
//   return useQuery({
//     queryKey: [COURSES_QUERY_KEY],
//     queryFn: () => {
//       return new Promise((resolve) => {
//         const coursesQuery = query(
//           collection(db, "courses"),
//           orderBy("createdAt", "desc"),
//         );
//         const unsubscribe = onSnapshot(coursesQuery, (snapshot) => {
//           const courses = snapshot.docs.map((doc) => ({
//             id: doc.id,
//             ...doc.data(),
//           }));
//           resolve(courses);
//           return () => unsubscribe();
//         });
//       });
//     },
//     staleTime: Infinity,
//   });
// }

import { collection, onSnapshot, query, orderBy } from "firebase/firestore";
import { db } from "../firebase";
import { useQuery } from "@tanstack/react-query";

const COURSES_QUERY_KEY = "courses";

export function useCourses() {
  return useQuery({
    queryKey: [COURSES_QUERY_KEY],
    queryFn: () => {
      return new Promise((resolve) => {
        const coursesQuery = query(
          collection(db, "courses"),
          orderBy("createdAt", "desc"),
        );
        const unsubscribe = onSnapshot(coursesQuery, (snapshot) => {
          const courses = snapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          }));
          resolve(courses);
        });
        return () => unsubscribe();
      });
    },
  });
}
