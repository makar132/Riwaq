import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  collection,
} from "firebase/firestore";
import { db } from "../firebase";

const COURSES_QUERY_KEY = "courses";

export function useAddCourse() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (newCourse) => addDoc(collection(db, "courses"), newCourse),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [COURSES_QUERY_KEY] });
    },
  });
}

export function useUpdateCourse() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, updatedFields }) =>
      updateDoc(doc(db, "courses", id), updatedFields),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [COURSES_QUERY_KEY] });
    },
  });
}

export function useDeleteCourse() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (courseId) => deleteDoc(doc(db, "courses", courseId)),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [COURSES_QUERY_KEY] });
    },
  });
}
