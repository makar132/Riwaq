import { collection, onSnapshot, query, orderBy } from "firebase/firestore";
import { db } from "../firebase";
import { useQuery } from "@tanstack/react-query";

const CATEGORIES_QUERY_KEY = "categories";

export function useCategories() {
  return useQuery({
    queryKey: [CATEGORIES_QUERY_KEY],
    queryFn: () => {
      return new Promise((resolve) => {
        const categoriesQuery = query(
          collection(db, "categories"),
          orderBy("createdAt", "desc"),
        );
        const unsubscribe = onSnapshot(categoriesQuery, (snapshot) => {
          const categories = snapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          }));
          resolve(categories);
        });
        return () => unsubscribe();
      });
    },
  });
}
