import { configureStore } from '@reduxjs/toolkit';
import { firestoreApi } from '../services/firestoreApi';
import auth from '../features/auth/authSlice';
import wishlist from '../features/wishlist/wishlistSlice';
import favourites from '../features/favourites/favouritesSlice';
import filters from '../features/courses/filtersSlice';
import { listenerMiddleware, startAuthListener } from './listenerMiddleware';

export const store = configureStore({
  reducer: {
    [firestoreApi.reducerPath]: firestoreApi.reducer,
    auth, wishlist, favourites, filters,
  },
  middleware: (gDM) => gDM().concat(firestoreApi.middleware, listenerMiddleware.middleware),
});

startAuthListener(store);