import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import ProtectedRoute from "./components/ProtectedRoute";
import Navbar from "./components/Navbar";
import { useSelector } from "react-redux";
import { selectIsAuthInitialized } from "./features/auth/authSlice";
import Reset from "./pages/Reset";
import NotFound from "./pages/NotFound";
import Forbidden from "./pages/Forbidden";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminCourses from "./pages/admin/AdminCourses";
import AdminCourseForm from "./pages/admin/AdminCourseForm";
import AdminCategories from "./pages/admin/AdminCategories";

export default function App() {
  const isInitialized = useSelector(selectIsAuthInitialized);

  if (!isInitialized) {
    return <div className="p-4 text-sm text-gray-600">Loading…</div>;
  }

  return (
    <BrowserRouter>
      {/* Use 100svh for mobile-safe viewport; min-h-0 lets children shrink */}
      <Navbar /> {/* fixed h-16 (make sure Navbar has h-16) */}
      {/* Main must have min-h-0 to allow overflow; pt-16 offsets fixed navbar */}
      <main className="pt-[var(--nav-h)]">
        <div className="min-h-[calc(100svh-var(--nav-h))] bg-gray-50">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="login" element={<Login />} />
            <Route path="register" element={<Register />} />
            <Route path="reset" element={<Reset />} />

            <Route
              path="dashboard"
              element={
                <ProtectedRoute requireAdmin>
                  <Dashboard />
                </ProtectedRoute>
              }
            />
            <Route path="403" element={<Forbidden />} />
            <Route
              path="/admin"
              element={
                <ProtectedRoute requireAdmin>
                  <AdminDashboard />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/courses"
              element={
                <ProtectedRoute requireAdmin>
                  <AdminCourses />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/courses/new"
              element={
                <ProtectedRoute requireAdmin>
                  <AdminCourseForm />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/courses/:id/edit"
              element={
                <ProtectedRoute requireAdmin>
                  <AdminCourseForm />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/categories"
              element={
                <ProtectedRoute requireAdmin>
                  <AdminCategories />
                </ProtectedRoute>
              }
            />

            <Route path="*" element={<NotFound />} />
          </Routes>
        </div>
      </main>
    </BrowserRouter>
  );
}
