import { useState } from "react";
import AdminLayout from "./AdminLayout";
import {
  useListCategoriesQuery,
  useCreateCategoryMutation,
  useUpdateCategoryMutation,
  useDeleteCategoryMutation,
} from "../../services/firestoreApi";

export default function AdminCategories() {
  const { data: categories = [], isFetching } = useListCategoriesQuery();
  const [createCategory, createState] = useCreateCategoryMutation();
  const [updateCategory] = useUpdateCategoryMutation();
  const [deleteCategory, delState] = useDeleteCategoryMutation();

  const [newName, setNewName] = useState("");

  return (
    <AdminLayout
      title="Categories"
      actions={
        <div className="flex gap-2">
          <input
            className="rounded-lg border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-[#49BBBD] focus:outline-none"
            placeholder="New category…"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
          />
          <button
            className="rounded-lg bg-[#49BBBD] px-3 py-2 text-white hover:opacity-90 disabled:opacity-60"
            disabled={createState.isLoading}
            onClick={() => {
              const v = newName.trim();
              if (v) {
                createCategory({ name: v });
                setNewName("");
              }
            }}
          >
            Add
          </button>
        </div>
      }
    >
      <ul className="divide-y">
        {categories.map((cat) => (
          <li key={cat.id} className="flex items-center justify-between py-3">
            <input
              defaultValue={cat.name}
              className="w-64 rounded-lg border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-[#49BBBD] focus:outline-none"
              onBlur={(e) => {
                const v = e.target.value.trim();
                if (v && v !== cat.name)
                  updateCategory({ id: cat.id, name: v });
              }}
            />
            <button
              className="text-red-600 hover:underline disabled:opacity-60"
              disabled={delState.isLoading}
              onClick={() => deleteCategory(cat.id)}
            >
              Delete
            </button>
          </li>
        ))}
        {!isFetching && categories.length === 0 && (
          <li className="py-8 text-center text-gray-500">No categories</li>
        )}
      </ul>
    </AdminLayout>
  );
}
