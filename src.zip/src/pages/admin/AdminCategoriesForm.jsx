import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

const CategoryFormPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ name: "" });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCategory = async () => {
      if (id) {
        const category = await apiSv.fetchCategoryById(id);
        if (category) {
          setFormData(category);
        }
      }
      setLoading(false);
    };
    fetchCategory();
  }, [id]);

  const handleChange = (e) => {
    setFormData({ name: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name) {
      alert("Please fill in the category name.");
      return;
    }

    if (id) {
      await apiSvc.updateCategory(id, formData);
    } else {
      await apiSvc.createCategory(formData);
    }
    navigate("/admin/categories");
  };

  if (loading)
    return (
      <AdminLayout>
        <div className="p-8 text-center">Loading...</div>
      </AdminLayout>
    );

  return (
    <AdminLayout>
      <h1 className="mb-6 text-3xl font-bold">
        {id ? "Edit Category" : "Create New Category"}
      </h1>
      <form
        onSubmit={handleSubmit}
        className="mx-auto max-w-xl rounded-xl border border-gray-200 bg-white p-6 shadow-sm"
      >
        <div className="space-y-4">
          <div>
            <label
              htmlFor="name"
              className="block text-sm font-medium text-gray-700"
            >
              Category Name
            </label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
            />
          </div>
        </div>
        <div className="mt-6 flex justify-end gap-3">
          <button
            type="button"
            onClick={() => navigate("/admin/categories")}
            className="rounded-md border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700"
          >
            {id ? "Save Changes" : "Create Category"}
          </button>
        </div>
      </form>
    </AdminLayout>
  );
};

export default CategoryFormPage;
