export default function AdminLayout({ title, actions, children }) {
  return (
    <div
      className="grid grid-cols-1 bg-gray-50 lg:grid-cols-[240px_1fr]"
      style={{ minHeight: "calc(100svh - var(--nav-h, 4rem))" }}
    >
      {/* Sidebar */}
      <aside className="hidden border-r border-gray-200 bg-white lg:block">
        <div className="px-4 py-4 text-lg font-extrabold tracking-tight text-[#49BBBD]">
          Admin
        </div>
        <nav className="space-y-1 px-2 pb-4">
          <a
            href="/admin"
            className="block rounded-lg px-3 py-2 hover:bg-gray-50"
          >
            Overview
          </a>
          <a
            href="/admin/courses"
            className="block rounded-lg px-3 py-2 hover:bg-gray-50"
          >
            Courses
          </a>
          <a
            href="/admin/categories"
            className="block rounded-lg px-3 py-2 hover:bg-gray-50"
          >
            Categories
          </a>
        </nav>
      </aside>

      {/* Content */}
      <section className="overflow-y-auto">
        <div className="mx-auto max-w-6xl p-4 sm:p-6">
          <header className="mb-4 flex items-center justify-between">
            <h1 className="text-2xl font-bold text-gray-900">{title}</h1>
            {actions ? <div className="flex gap-2">{actions}</div> : null}
          </header>

          <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm sm:p-6">
            {children}
          </div>
        </div>
      </section>
    </div>
  );
}
