// src/pages/admin/AdminCourses.jsx
// import { useEffect, useMemo, useRef, useState, useCallback } from "react";
// import { Link } from "react-router-dom";
// import AdminLayout from "./AdminLayout";
// import {
//   useGetCoursesPageQuery,
//   useDeleteCourseMutation,
//   useCountCoursesQuery,
// } from "../../services/firestoreApi";
import CourseTable from "../../components/CourseTable";

export default function AdminCourses() {
  // // ---- base filters (changing these resets pagination) ----
  // const [base, setBase] = useState({
  //   search: "",
  //   sortBy: "createdAt",
  //   dir: "desc",
  //   pageSize: 2,
  //   publishedOnly: false,
  //   categoryId: undefined,
  // });

  // // ---- local pagination cache ----
  // // each page: { items, firstDoc, lastDoc, hasNext }
  // const [pages, setPages] = useState([]);
  // const [index, setIndex] = useState(0);

  // // intent: null | 'init' | 'next'
  // const [intent, setIntent] = useState("init"); // auto-load first page

  // // reset cache if base filters change
  // const baseKey = useMemo(() => JSON.stringify(base), [base]);
  // const prevBaseKey = useRef(baseKey);
  // useEffect(() => {
  //   if (prevBaseKey.current !== baseKey) {
  //     prevBaseKey.current = baseKey;
  //     setPages([]);
  //     setIndex(0);
  //     setIntent("init");
  //   }
  // }, [baseKey]);

  // // ------ total count & total pages (reactive) ------
  // const countArgs = {
  //   search: base.search,
  //   publishedOnly: base.publishedOnly,
  //   categoryId: base.categoryId,
  // };
  // const { data: countData } = useCountCoursesQuery(countArgs, {
  //   refetchOnMountOrArgChange: true,
  //   refetchOnFocus: true,
  //   refetchOnReconnect: true,
  // });
  // const totalCount = countData?.count ?? 0;
  // const totalPages = Math.max(1, Math.ceil((totalCount || 0) / base.pageSize));

  // // Clamp index if totalPages shrinks (e.g., filter/delete)
  // useEffect(() => {
  //   if (index > totalPages - 1) setIndex(totalPages - 1);
  //   // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, [totalPages]);

  // // ------ init fetch (first page) ------
  // const initArgs = useMemo(() => {
  //   if (intent !== "init") return null;
  //   return { ...base, direction: "init", cursorId: "first" };
  // }, [intent, base]);

  // const { data: initData, isFetching: isInitFetching } = useGetCoursesPageQuery(
  //   initArgs ?? {},
  //   {
  //     skip: !initArgs,
  //     refetchOnMountOrArgChange: true,
  //     refetchOnFocus: true,
  //     refetchOnReconnect: true,
  //   },
  // );

  // useEffect(() => {
  //   if (!initData) return;
  //   setPages([
  //     {
  //       items: initData.items,
  //       firstDoc: initData.firstDoc,
  //       lastDoc: initData.lastDoc,
  //       hasNext: initData.hasNext,
  //     },
  //   ]);
  //   setIndex(0);
  //   setIntent(null);
  // }, [initData]);

  // // ------ next fetch only when needed ------
  // const needNext = useMemo(() => {
  //   if (intent !== "next") return false;
  //   const cur = pages[index];
  //   if (!cur) return false;
  //   if (pages[index + 1]) return false; // already cached
  //   return !!cur.hasNext && !!cur.lastDoc; // only fetch if more exists
  // }, [intent, pages, index]);

  // const nextArgs = useMemo(() => {
  //   if (!needNext) return null;
  //   const cur = pages[index];
  //   return {
  //     ...base,
  //     direction: "next",
  //     cursorLast: cur.lastDoc,
  //     cursorId: `after:${cur.lastDoc.id}`,
  //   };
  // }, [needNext, base, pages, index]);

  // const { data: nextData, isFetching: isNextFetching } = useGetCoursesPageQuery(
  //   nextArgs ?? {},
  //   {
  //     skip: !nextArgs,
  //     refetchOnMountOrArgChange: true,
  //     refetchOnFocus: true,
  //     refetchOnReconnect: true,
  //   },
  // );

  // useEffect(() => {
  //   if (!nextData) return;
  //   setPages((prev) => {
  //     const nextPageIdx = index + 1;
  //     // If we were moving forward and the next page isn't cached yet -> append
  //     if (intent === "next" && !prev[nextPageIdx]) {
  //       return [
  //         ...prev,
  //         {
  //           items: nextData.items,
  //           firstDoc: nextData.firstDoc,
  //           lastDoc: nextData.lastDoc,
  //           hasNext: nextData.hasNext,
  //         },
  //       ];
  //     }
  //     // If the next page IS already cached (RTK served cached then refetched) -> replace it
  //     if (prev[nextPageIdx]) {
  //       const copy = [...prev];
  //       copy[nextPageIdx] = {
  //         ...copy[nextPageIdx],
  //         items: nextData.items,
  //         firstDoc: nextData.firstDoc,
  //         lastDoc: nextData.lastDoc,
  //         hasNext: nextData.hasNext,
  //       };
  //       return copy;
  //     }
  //     return prev;
  //   });
  //   // If we were advancing and we just appended, move the index forward
  //   if (intent === "next" && !pages[index + 1]) {
  //     setIndex((i) => i + 1);
  //   }
  //   setIntent(null);
  // }, [nextData]); // <- don't depend on intent to still update on refetch
  // // ---- derived UI state ----
  // const current = pages[index] || { items: [], hasNext: false };
  // const items = current.items;
  // const hasPrev = index > 0;
  // // Gate Next by either page hint OR known total pages
  // const canNext = !!current.hasNext || index < totalPages - 1;
  // const isFetching = isInitFetching || isNextFetching;

  // const [deleteCourse, delState] = useDeleteCourseMutation();

  // // after delete, refresh from start (simple + consistent)
  // const refreshFromStart = useCallback(() => {
  //   setPages([]);
  //   setIndex(0);
  //   setIntent("init");
  // }, []);

  // const goPrev = useCallback(() => {
  //   if (!hasPrev || isFetching) return;
  //   setIndex((i) => Math.max(0, i - 1));
  // }, [hasPrev, isFetching]);

  // const goNext = useCallback(() => {
  //   if (!canNext || isFetching) return;
  //   if (pages[index + 1]) setIndex((i) => i + 1);
  //   else setIntent("next");
  // }, [canNext, isFetching, pages, index]);

  return (
    // <AdminLayout
    //   title="Courses"
    //   actions={
    //     <Link
    //       to="/admin/courses/new"
    //       className="rounded-lg bg-[#49BBBD] px-3 py-2 text-white hover:opacity-90"
    //     >
    //       New Course
    //     </Link>
    //   }
    // >
    //   {/* Filters */}
    //   <div className="mb-4 flex flex-wrap gap-2">
    //     <input
    //       className="w-full rounded-lg border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-[#49BBBD] focus:outline-none sm:w-64"
    //       placeholder="Search title…"
    //       value={base.search}
    //       onChange={(e) => setBase((p) => ({ ...p, search: e.target.value }))}
    //     />

    //     <select
    //       className="rounded-lg border border-gray-300 px-3 py-2"
    //       value={`${base.sortBy}:${base.dir}`}
    //       onChange={(e) => {
    //         const [sortBy, dir] = e.target.value.split(":");
    //         setBase((p) => ({ ...p, sortBy, dir }));
    //       }}
    //     >
    //       <option value="createdAt:desc">Newest</option>
    //       <option value="createdAt:asc">Oldest</option>
    //       <option value="title:asc">Title A→Z</option>
    //       <option value="title:desc">Title Z→A</option>
    //     </select>
    //   </div>

    //   {/* Table */}
    //   <div className="overflow-x-auto">
    //     <table className="min-w-full text-sm">
    //       <thead>
    //         <tr className="text-left text-gray-500">
    //           <th className="py-2 pr-3">Title</th>
    //           <th className="px-3 py-2">Category</th>
    //           <th className="px-3 py-2">Price</th>
    //           <th className="px-3 py-2">Published</th>
    //           <th className="py-2 pl-3 text-right">Actions</th>
    //         </tr>
    //       </thead>
    //       <tbody>
    //         {items.map((c) => (
    //           <tr key={c.id} className="border-t">
    //             <td className="py-2 pr-3">{c.title}</td>
    //             <td className="px-3 py-2">{c.categoryId || "—"}</td>
    //             <td className="px-3 py-2">
    //               {c.price} {c.currency}
    //             </td>
    //             <td className="px-3 py-2">{c.isPublished ? "Yes" : "No"}</td>
    //             <td className="py-2 pl-3 text-right">
    //               <div className="inline-flex gap-2">
    //                 <Link
    //                   to={`/admin/courses/${c.id}/edit`}
    //                   className="text-[#49BBBD] hover:underline"
    //                 >
    //                   Edit
    //                 </Link>
    //                 <button
    //                   onClick={async () => {
    //                     await deleteCourse(c.id);
    //                     refreshFromStart();
    //                   }}
    //                   className="text-red-600 hover:underline"
    //                   disabled={delState.isLoading}
    //                 >
    //                   Delete
    //                 </button>
    //               </div>
    //             </td>
    //           </tr>
    //         ))}
    //         {!isFetching && items.length === 0 && (
    //           <tr>
    //             <td colSpan={5} className="py-8 text-center text-gray-500">
    //               No courses
    //             </td>
    //           </tr>
    //         )}
    //       </tbody>
    //     </table>
    //   </div>

    //   {/* Pager */}
    //   <div className="mt-4 flex items-center justify-between">
    //     <button
    //       className="rounded-lg border px-3 py-2 hover:bg-gray-50 disabled:opacity-50"
    //       disabled={!hasPrev || isFetching}
    //       onClick={goPrev}
    //     >
    //       Prev
    //     </button>

    //     <div className="text-sm text-gray-500">
    //       Page {pages.length ? index + 1 : 0} of {totalPages}
    //     </div>

    //     <button
    //       className="rounded-lg border px-3 py-2 hover:bg-gray-50 disabled:opacity-50"
    //       disabled={!canNext || isFetching}
    //       onClick={goNext}
    //     >
    //       {isFetching ? "Loading…" : canNext ? "Next" : "No more"}
    //     </button>
    //   </div>
    // </AdminLayout>
    <>
      <CourseTable />
    </>
  );
}
