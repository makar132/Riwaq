import React from "react";
import AdminLayout from "../../components/AdminLayout";
import { useCourses } from "../../hooks/useCourses";
import { useCategories } from "../../hooks/useCategories";

export default function AdminDashboard() {
  const { data: courses, isLoading: coursesLoading } = useCourses();
  const { data: categories, isLoading: categoriesLoading } = useCategories();

  const totalCourses = courses?.length || 0;
  const totalCategories = categories?.length || 0;

  const stats = [
    { title: "Total Courses", value: totalCourses },
    { title: "Total Categories", value: totalCategories },
  ];

  return (
    <AdminLayout title="Overview">
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
        {stats.map((stat, index) => (
          <div
            key={index}
            className="rounded-xl border border-gray-200 bg-gray-50 p-6"
          >
            <p className="text-sm font-medium text-gray-500">{stat.title}</p>
            <p className="mt-1 text-3xl font-bold text-gray-900">
              {stat.value}
            </p>
          </div>
        ))}
      </div>
    </AdminLayout>
  );
}
