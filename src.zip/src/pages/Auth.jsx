// src/pages/Auth.jsx
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { useDispatch, useSelector } from "react-redux";
import {
  signInWithIdentifier,
  signUp,
  signOut,
} from "../features/auth/authSlice";

const LoginSchema = Yup.object({
  identifier: Yup.string().required("Required"), // username or email
  password: Yup.string().min(6, "Too short").required("Required"),
});

const SignupSchema = Yup.object({
  name: Yup.string().min(2).required("Required"),
  email: Yup.string().email("Invalid email").required("Required"),
  username: Yup.string().min(3).required("Required"),
  password: Yup.string().min(6).required("Required"),
  confirm: Yup.string()
    .oneOf([Yup.ref("password")], "Passwords must match")
    .required("Required"),
  locale: Yup.string().oneOf(["en", "ar"]).required(),
});

export default function AuthPage() {
  const dispatch = useDispatch();
  const user = useSelector((s) => s.auth.user);

  return (
    <div className="grid gap-8 p-6 md:grid-cols-2">
      {/* Sign In */}
      <section>
        <h2 className="mb-3 font-bold">Sign In</h2>
        <Formik
          initialValues={{ identifier: "", password: "" }}
          validationSchema={LoginSchema}
          onSubmit={(v, { setSubmitting }) => {
            dispatch(signInWithIdentifier(v)).finally(() =>
              setSubmitting(false),
            );
          }}
        >
          {({ isSubmitting }) => (
            <Form className="space-y-3">
              <div>
                <label className="block text-sm font-medium">
                  Email or Username
                </label>
                <Field
                  name="identifier"
                  className="input w-full"
                  placeholder="me@example.com or myusername"
                />
                <ErrorMessage
                  name="identifier"
                  component="p"
                  className="text-sm text-red-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium">Password</label>
                <Field
                  name="password"
                  type="password"
                  className="input w-full"
                />
                <ErrorMessage
                  name="password"
                  component="p"
                  className="text-sm text-red-500"
                />
              </div>
              <button
                className="btn btn-primary"
                type="submit"
                disabled={isSubmitting}
              >
                Sign In
              </button>
            </Form>
          )}
        </Formik>
      </section>

      {/* Sign Up */}
      <section>
        <h2 className="mb-3 font-bold">Create Account</h2>
        <Formik
          initialValues={{
            name: "",
            email: "",
            username: "",
            password: "",
            confirm: "",
            locale: "en",
          }}
          validationSchema={SignupSchema}
          onSubmit={(v, { setSubmitting }) => {
            const { confirm, ...payload } = v;
            dispatch(signUp(payload)).finally(() => setSubmitting(false));
          }}
        >
          {({ isSubmitting }) => (
            <Form className="space-y-3">
              <div>
                <label className="block text-sm font-medium">Name</label>
                <Field name="name" className="input w-full" />
                <ErrorMessage
                  name="name"
                  component="p"
                  className="text-sm text-red-500"
                />
              </div>
              <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                <div>
                  <label className="block text-sm font-medium">Email</label>
                  <Field name="email" type="email" className="input w-full" />
                  <ErrorMessage
                    name="email"
                    component="p"
                    className="text-sm text-red-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium">Username</label>
                  <Field name="username" className="input w-full" />
                  <ErrorMessage
                    name="username"
                    component="p"
                    className="text-sm text-red-500"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                <div>
                  <label className="block text-sm font-medium">Password</label>
                  <Field
                    name="password"
                    type="password"
                    className="input w-full"
                  />
                  <ErrorMessage
                    name="password"
                    component="p"
                    className="text-sm text-red-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium">
                    Confirm Password
                  </label>
                  <Field
                    name="confirm"
                    type="password"
                    className="input w-full"
                  />
                  <ErrorMessage
                    name="confirm"
                    component="p"
                    className="text-sm text-red-500"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium">Language</label>
                <Field as="select" name="locale" className="input w-full">
                  <option value="en">English</option>
                  <option value="ar">Arabic</option>
                </Field>
                <ErrorMessage
                  name="locale"
                  component="p"
                  className="text-sm text-red-500"
                />
              </div>
              <button
                className="btn btn-primary"
                type="submit"
                disabled={isSubmitting}
              >
                Create Account
              </button>
            </Form>
          )}
        </Formik>

        {user && (
          <div className="mt-6">
            <p className="text-sm">
              Signed in as <strong>{user.name || user.email}</strong>
            </p>
            <button className="btn mt-2" onClick={() => dispatch(signOut())}>
              Sign Out
            </button>
          </div>
        )}
      </section>
    </div>
  );
}
