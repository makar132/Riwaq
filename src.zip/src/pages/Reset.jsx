import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import AuthLayout from '../components/AuthLayout';
import * as authSvc from '../services/auth';
import { useState } from 'react';
import { Link } from 'react-router-dom';

const ResetSchema = Yup.object({
  emailOrUsername: Yup.string().required('Required'),
});

export default function Reset() {
  const [serverMsg, setServerMsg] = useState(null);

  return (
    <AuthLayout
      title="Reset your password"
      subtitle="We’ll send a password reset link to your email."
      imageSrc="/reset-password.svg"
    >
      {serverMsg && (
        <div className={`mb-3 -mt-10 rounded-lg text-sm px-3 py-2 ${
          serverMsg.startsWith('If') ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
        }`}>
          {serverMsg}
        </div>
      )}

      <Formik
        initialValues={{ emailOrUsername: '' }}
        validationSchema={ResetSchema}
        onSubmit={async (v, { setSubmitting }) => {
          setServerMsg(null);
          const res = await authSvc.resetPassword(v);
          setSubmitting(false);
          setServerMsg(res.ok ? 'If the account exists, a reset email has been sent.' : res.error.message);
        }}
      >
        {({ isSubmitting }) => (
          <Form className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Email or Username</label>
              <Field
                name="emailOrUsername"
                className="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <div className="h-5 mt-1">
                <ErrorMessage name="emailOrUsername" component="p" className="text-xs text-red-600" />
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full inline-flex items-center justify-center rounded-lg bg-blue-600 px-4 py-2.5 text-white font-medium shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-60"
            >
              {isSubmitting ? 'Sending…' : 'Send reset email'}
            </button>

            <p className="text-sm text-gray-600">
              <Link to="/login" className="text-blue-600 hover:text-blue-700 font-medium">Back to login</Link>
            </p>
          </Form>
        )}
      </Formik>
    </AuthLayout>
    
  );
}
