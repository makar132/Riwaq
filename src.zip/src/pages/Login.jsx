import { Formik, Form } from "formik";
import * as Yup from "yup";
import AuthLayout from "../components/AuthLayout";
import FieldRow from "../components/InputField";
import * as authSvc from "../services/auth";
import { useState } from "react";
import { useAuth } from "../auth/useAuth";
import { Link, useNavigate, useLocation } from "react-router-dom";
import PasswordField from "../components/PasswordField";

const LoginSchema = Yup.object({
  identifier: Yup.string().required("Required"),
  password: Yup.string().min(6, "Too short").required("Required"),
});

export default function Login() {
  const [serverMsg, setServerMsg] = useState(null);
  const { user } = useAuth();
  const navigate = useNavigate();
  const { search } = useLocation();
  const redirectTo = new URLSearchParams(search).get("redirect") || "/";

  const onSuccess = () => navigate(redirectTo, { replace: true });

  return (
    <AuthLayout
      title="Welcome back"
      subtitle="Sign in to continue learning."
      from="from-[#49BBBD]"
      via="via-[#36A2A4]"
      to="to-[#2F7E80]" // sample: closer to your teal brand
      imageSrc="/login.svg"
      brandName="Riwaq"
    >
      {/* top banner slot; prevent layout jump via reserved space in layout */}
      {serverMsg && (
        <div
          role="status"
          aria-live="polite"
          className="-mt-10 mb-3 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700"
        >
          {serverMsg}
        </div>
      )}

      <Formik
        initialValues={{ identifier: "", password: "" }}
        validationSchema={LoginSchema}
        onSubmit={async (vals, { setSubmitting, setFieldError }) => {
          setServerMsg(null);
          const res = await authSvc.login(vals);
          setSubmitting(false);
          if (!res.ok) {
            Object.entries(res.error.fieldErrors || {}).forEach(([k, msg]) =>
              setFieldError(k, msg),
            );
            setServerMsg(res.error.message);
          } else {
            onSuccess();
          }
        }}
      >
        {({ isSubmitting }) => (
          <Form className="space-y-6">
            <FieldRow
              name="identifier"
              label="Email or Username"
              placeholder="me@example.com or myusername"
              autoComplete="username"
            />

            <div>
              <div className="flex items-center justify-between">
                <label className="block text-[0.95rem] font-medium text-gray-800">
                  Password
                </label>
                <Link
                  to="/reset"
                  className="text-sm text-blue-600 hover:text-blue-700"
                >
                  Forgot?
                </Link>
              </div>
              <PasswordField
                name="password"
                label="" // label is above
                autoComplete="current-password"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="inline-flex w-full items-center justify-center rounded-2xl bg-blue-400 px-4 py-3.5 text-[17px] font-semibold text-white shadow-sm hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:outline-none disabled:opacity-60"
            >
              {isSubmitting ? "Signing in…" : "Sign In"}
            </button>

            <p className="text-sm text-gray-600">
              Don’t have an account?{" "}
              <Link
                to="/register"
                className="font-medium text-blue-600 hover:text-blue-700"
              >
                Create one
              </Link>
            </p>

            {user && (
              <div className="rounded-lg bg-green-50 px-3 py-2 text-xs text-green-700">
                You’re signed in as{" "}
                <span className="font-medium">{user.name || user.email}</span>.
              </div>
            )}
          </Form>
        )}
      </Formik>
    </AuthLayout>
  );
}
