import { useEffect, useMemo, useState } from "react";
import { onAuthStateChanged } from "firebase/auth";
import { auth, db } from "../firebase";
import { doc, onSnapshot } from "firebase/firestore";
import { AuthContext } from "./AuthContextBase";

export default function AuthProvider({ children }) {
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);

  useEffect(() => {
    let unsubProfile = null;

    const unsubAuth = onAuthStateChanged(auth, (fbUser) => {
      // cleanup previous profile sub
      if (unsubProfile) {
        try {
          unsubProfile();
        } catch {}
        unsubProfile = null;
      }

      if (!fbUser) {
        setUser(null);
        setLoading(false);
        return;
      }

      const ref = doc(db, "users", fbUser.uid);
      unsubProfile = onSnapshot(
        ref,
        (snap) => {
          const data = snap.data() || {};
          setUser({ uid: fbUser.uid, ...data });
          setLoading(false);
        },
        () => {
          // on error, still mark initialized
          setLoading(false);
        },
      );
    });

    return () => {
      if (unsubProfile) {
        try {
          unsubProfile();
        } catch {}
      }
      unsubAuth();
    };
  }, []);

  const value = useMemo(() => ({ user, loading }), [user, loading]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
