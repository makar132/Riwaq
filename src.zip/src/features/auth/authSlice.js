import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { auth, db } from "../../firebase";
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  signOut as _signOut,
} from "firebase/auth";
import { doc, getDoc, setDoc } from "firebase/firestore";

// --- thunks you already had (trimmed) ---
export const signInWithIdentifier = createAsyncThunk(
  "auth/signInWithIdentifier",
  async ({ identifier, password }, { rejectWithValue }) => {
    let email = identifier;
    if (!identifier.includes("@")) {
      const u = await getDoc(doc(db, "usernames", identifier));
      if (!u.exists()) return rejectWithValue("USERNAME_NOT_FOUND");
      email = u.data().email;
    }
    await signInWithEmailAndPassword(auth, email, password);
    return true;
  },
);

export const signUp = createAsyncThunk(
  "auth/signUp",
  async (
    { name, email, username, password, locale = "en" },
    { rejectWithValue },
  ) => {
    const u = await getDoc(doc(db, "usernames", username));
    if (u.exists()) return rejectWithValue("USERNAME_TAKEN");
    const cred = await createUserWithEmailAndPassword(auth, email, password);
    await updateProfile(cred.user, { displayName: name });
    await setDoc(doc(db, "users", cred.user.uid), {
      email,
      name,
      isAdmin: false,
      preferences: { locale },
      wishlist: [],
      favourites: [],
    });
    await setDoc(doc(db, "usernames", username), { email, uid: cred.user.uid });
    return true;
  },
);

export const signOut = createAsyncThunk("auth/signOut", async () => {
  await _signOut(auth);
});

// --- slice ---
const slice = createSlice({
  name: "auth",
  initialState: {
    user: null,
    isInitialized: false,
    status: "idle",
    error: null,
  },
  reducers: {
    setCurrentUser(state, { payload }) {
      state.user = payload;
    },
    setAuthInitialized(state, { payload }) {
      state.isInitialized = payload;
    },
  },
  extraReducers: (b) => {
    b.addCase(signInWithIdentifier.rejected, (s, a) => {
      s.error = a.payload || "LOGIN_FAILED";
    });
    b.addCase(signUp.rejected, (s, a) => {
      s.error = a.payload || "SIGNUP_FAILED";
    });
    b.addCase(signOut.fulfilled, (s) => {
      s.user = null;
    });
  },
});

export const { setCurrentUser, setAuthInitialized } = slice.actions;
export default slice.reducer;

// --- selectors (so your App.jsx imports keep working) ---
export const selectCurrentUser = (s) => s.auth.user;
export const selectIsAuthInitialized = (s) => s.auth.isInitialized;
