import { createSlice } from '@reduxjs/toolkit';
const slice = createSlice({
  name: 'filters',
  initialState: { search: '', categoryId: null, sortBy: 'createdAt', dir: 'desc', priceMin: null, priceMax: null },
  reducers: {
    setSearch: (s, a) => { s.search = a.payload; },
    setCategory: (s, a) => { s.categoryId = a.payload; },
    setSort: (s, a) => { s.sortBy = a.payload.sortBy; s.dir = a.payload.dir; },
  }
});
export const { setSearch, setCategory, setSort } = slice.actions;
export default slice.reducer;
