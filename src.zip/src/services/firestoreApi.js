import { createApi, fakeBaseQuery } from "@reduxjs/toolkit/query/react";
import { db } from "../firebase";
import {
  collection,
  doc,
  query,
  where,
  orderBy,
  limit,
  limitToLast,
  startAfter,
  startAt,
  endAt,
  endBefore,
  onSnapshot,
  getDoc,
  getDocs,
  addDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  serverTimestamp,
  getCountFromServer,
} from "firebase/firestore";

export const firestoreApi = createApi({
  reducerPath: "firestoreApi",
  baseQuery: fakeBaseQuery(),
  tagTypes: ["Course", "Category", "Enrollment", "User"],
  endpoints: (b) => ({
    // Courses list with filters/search/pagination (real-time)
    listCourses: b.query({
      queryFn: () => ({ data: null }),
      async onCacheEntryAdded(args, { updateCachedData, cacheEntryRemoved }) {
        const {
          search = "",
          sortBy = "createdAt",
          dir = "desc",
          pageSize = 12,
          cursor,
          categoryId,
          publishedOnly = true,
        } = args;
        const hardLimit = (pageSize ?? 1) + 1;
        const clauses = [];
        if (publishedOnly) clauses.push(where("isPublished", "==", true));
        if (categoryId) clauses.push(where("categoryId", "==", categoryId));

        let constraints = [...clauses];
        if (search.trim()) {
          const t = search.trim().toLowerCase();
          constraints.push(
            orderBy("title_lc"),
            startAt(t),
            endAt(t + "\uf8ff"),
            limit(hardLimit),
          );
        } else {
          const field = sortBy === "title" ? "title_lc" : sortBy;
          constraints.push(orderBy(field, dir), limit(hardLimit));
        }

        if (cursor) constraints.push(startAfter(cursor));

        const q = query(collection(db, "courses"), ...constraints);
        const unsub = onSnapshot(q, (snap) => {
          const docs = snap.docs;
          const hasMore = docs.length === hardLimit;
          // show first `pageSize` docs
          const pageDocs = hasMore ? docs.slice(0, pageSize) : docs;
          updateCachedData(() => ({
            items: pageDocs.map((d) => ({
              id: d.id,
              ...d.data(),
              _cursor: d, // keep if you want to inspect cursors in UI
            })),
            // ✅ cursor should be the last *displayed* doc
            nextCursor: hasMore ? pageDocs[pageDocs.length - 1] : null,
            hasMore,
          }));
        });
        await cacheEntryRemoved;
        unsub();
      },
      providesTags: (res) =>
        res?.items?.map((i) => ({ type: "Course", id: i.id })) ?? [
          { type: "Course", id: "LIST" },
        ],
    }),
    // inside endpoints: (b) => ({ ... })
    getCoursesPage: b.query({
      // We’ll serialize args manually so snapshots in args don't pollute the cache key
      providesTags: [{ type: "Course", id: "LIST" }],
      serializeQueryArgs: ({ endpointName, queryArgs }) => {
        const {
          search = "",
          sortBy = "createdAt",
          dir = "desc",
          pageSize = 10,
          publishedOnly = false,
          categoryId,
          direction = "init",
          cursorId = "first",
        } = queryArgs;
        return [
          endpointName,
          search,
          sortBy,
          dir,
          pageSize,
          publishedOnly,
          categoryId,
          direction,
          cursorId,
        ].join("|");
      },
      async queryFn(args) {
        const {
          search = "",
          sortBy = "createdAt", // 'createdAt' | 'title'
          dir = "desc", // 'asc' | 'desc'
          pageSize = 10,
          publishedOnly = false,
          categoryId,
          direction = "init", // 'init' | 'next' | 'prev'
          cursorFirst, // QueryDocumentSnapshot (for prev)
          cursorLast, // QueryDocumentSnapshot (for next)
        } = args;

        const clauses = [];
        if (publishedOnly) clauses.push(where("isPublished", "==", true));
        if (categoryId) clauses.push(where("categoryId", "==", categoryId));

        const constraints = [...clauses];

        // Base ordering + search window
        if (search.trim()) {
          const term = search.trim().toLowerCase();
          constraints.push(
            orderBy("title_lc"),
            startAt(term),
            endAt(term + "\uf8ff"),
          );
        } else {
          const field = sortBy === "title" ? "title_lc" : sortBy;
          constraints.push(orderBy(field, dir));
        }

        // Pagination
        if (direction === "next" && cursorLast) {
          // Overfetch by 1 to detect hasNext on "next"
          constraints.push(startAfter(cursorLast), limit((pageSize ?? 1) + 1));
        } else if (direction === "prev" && cursorFirst) {
          // Prev page: endBefore + limitToLast(pageSize)
          constraints.push(endBefore(cursorFirst), limitToLast(pageSize));
        } else {
          // First page (init)
          constraints.push(limit((pageSize ?? 1) + 1));
        }

        try {
          const q = query(collection(db, "courses"), ...constraints);
          const snap = await getDocs(q);
          const docs = snap.docs;

          let items = [];
          let firstDoc = null;
          let lastDoc = null;
          let hasNext = false;

          if (direction === "prev") {
            // Prev does not overfetch
            items = docs.map((d) => ({ id: d.id, ...d.data() }));
            firstDoc = docs[0] ?? null;
            lastDoc = docs[docs.length - 1] ?? null;
          } else {
            // Init or next: overfetch by 1 to compute hasNext
            const over = (pageSize ?? 1) + 1;
            const hasMore = docs.length > pageSize;
            const pageDocs = hasMore ? docs.slice(0, pageSize) : docs;
            items = pageDocs.map((d) => ({ id: d.id, ...d.data() }));
            firstDoc = pageDocs[0] ?? null;
            lastDoc = pageDocs[pageDocs.length - 1] ?? null;
            hasNext = docs.length === over;
          }

          // Expose cursor IDs for cache key friendliness
          const cursorId = lastDoc?.id || "last";
          return { data: { items, firstDoc, lastDoc, hasNext, cursorId } };
        } catch (e) {
          return { error: e };
        }
      },
    }),

    getCourse: b.query({
      async queryFn(id) {
        const d = await getDoc(doc(db, "courses", id));
        return d.exists()
          ? { data: { id: d.id, ...d.data() } }
          : { error: { status: 404 } };
      },
      providesTags: (r, e, id) => [{ type: "Course", id }],
    }),

    createCourse: b.mutation({
      async queryFn(payload) {
        const data = {
          ...payload,
          title: payload.title ?? "",
          title_lc: (payload.title ?? "").toLowerCase(),
          createdAt: serverTimestamp(),
        };
        const ref = await addDoc(collection(db, "courses"), data);
        return { data: { id: ref.id } };
      },
      invalidatesTags: [
        { type: "Course", id: "LIST" },
        { type: "Course", id: "COUNT" },
      ],
    }),

    updateCourse: b.mutation({
      async queryFn({ id, ...patch }) {
        const data = patch.title
          ? { ...patch, title_lc: patch.title.toLowerCase() }
          : patch;
        await updateDoc(doc(db, "courses", id), data);
        return { data: { id } };
      },
      invalidatesTags: (r, e, { id }) => [
        { type: "Course", id },
        { type: "Course", id: "LIST" },
        { type: "Course", id: "COUNT" },
      ],
    }),

    deleteCourse: b.mutation({
      async queryFn(id) {
        await deleteDoc(doc(db, "courses", id));
        return { data: { id } };
      },
      invalidatesTags: [
        { type: "Course", id: "LIST" },
        { type: "Course", id: "COUNT" },
      ],
    }),
    // countCourses: b.query({
    //   async queryFn({ publishedOnly = true } = {}) {
    //     const base = collection(db, "courses");
    //     const q = publishedOnly
    //       ? query(base, where("isPublished", "==", true))
    //       : query(base);
    //     const snap = await getCountFromServer(q);
    //     return { data: { count: snap.data().count } };
    //   },
    //   providesTags: [{ type: "Course", id: "COUNT" }],
    // }),
    countCourses: b.query({
      // Stable key that changes when relevant filters change
      serializeQueryArgs: ({ endpointName, queryArgs }) => {
        const {
          search = "",
          publishedOnly = false,
          categoryId = undefined,
        } = queryArgs || {};
        return [endpointName, search, publishedOnly, categoryId].join("|");
      },
      async queryFn(args = {}) {
        const { search = "", publishedOnly = false, categoryId } = args;

        const clauses = [];
        if (publishedOnly) clauses.push(where("isPublished", "==", true));
        if (categoryId) clauses.push(where("categoryId", "==", categoryId));

        const constraints = [...clauses];
        if (search.trim()) {
          const term = search.trim().toLowerCase();
          constraints.push(
            orderBy("title_lc"),
            startAt(term),
            endAt(term + "\uf8ff"),
          );
        }

        const q = query(collection(db, "courses"), ...constraints);
        const agg = await getCountFromServer(q);
        return { data: { count: agg.data().count } };
      },
      providesTags: [{ type: "Course", id: "COUNT" }],
    }),
    listCategories: b.query({
      async queryFn() {
        const snap = await getDocs(collection(db, "categories"));
        return { data: snap.docs.map((d) => ({ id: d.id, ...d.data() })) };
      },
      providesTags: [{ type: "Category", id: "LIST" }],
    }),
    createCategory: b.mutation({
      async queryFn({ name }) {
        const ref = await addDoc(collection(db, "categories"), { name });
        return { data: { id: ref.id } };
      },
      invalidatesTags: [{ type: "Category", id: "LIST" }],
    }),

    updateCategory: b.mutation({
      async queryFn({ id, name }) {
        await updateDoc(doc(db, "categories", id), { name });
        return { data: { id } };
      },
      invalidatesTags: [{ type: "Category", id: "LIST" }],
    }),

    deleteCategory: b.mutation({
      async queryFn(id) {
        await deleteDoc(doc(db, "categories", id));
        return { data: { id } };
      },
      invalidatesTags: [{ type: "Category", id: "LIST" }],
    }),
    countCategories: b.query({
      async queryFn() {
        const snap = await getCountFromServer(collection(db, "categories"));
        return { data: { count: snap.data().count } };
      },
      providesTags: [{ type: "Category", id: "COUNT" }],
    }),

    // Enrollments as subcollection under user (real-time)
    listEnrollments: b.query({
      queryFn: () => ({ data: null }),
      async onCacheEntryAdded(uid, { updateCachedData, cacheEntryRemoved }) {
        if (!uid) return;
        const q = query(
          collection(db, "users", uid, "enrollments"),
          orderBy("joinedAt", "desc"),
        );
        const unsub = onSnapshot(q, (snap) => {
          updateCachedData(() =>
            snap.docs.map((d) => ({ id: d.id, ...d.data() })),
          );
        });
        await cacheEntryRemoved;
        unsub();
      },
      providesTags: (res) =>
        (res || []).map((e) => ({ type: "Enrollment", id: e.courseId })),
    }),

    joinCourse: b.mutation({
      async queryFn({ uid, courseId }) {
        await setDoc(
          doc(db, "users", uid, "enrollments", courseId),
          {
            courseId,
            joinedAt: serverTimestamp(),
            progress: 0,
          },
          { merge: true },
        );
        return { data: true };
      },
      invalidatesTags: (r, e, { courseId }) => [
        { type: "Enrollment", id: courseId },
      ],
    }),

    unjoinCourse: b.mutation({
      async queryFn({ uid, courseId }) {
        await deleteDoc(doc(db, "users", uid, "enrollments", courseId));
        return { data: true };
      },
      invalidatesTags: (r, e, { courseId }) => [
        { type: "Enrollment", id: courseId },
      ],
    }),

    updateProgress: b.mutation({
      async queryFn({ uid, courseId, progress }) {
        await updateDoc(doc(db, "users", uid, "enrollments", courseId), {
          progress,
        });
        return { data: true };
      },
      invalidatesTags: (r, e, { courseId }) => [
        { type: "Enrollment", id: courseId },
      ],
    }),

    // Minimal lessons (future-friendly)
    listLessonsByCourse: b.query({
      async queryFn(courseId) {
        const q = query(
          collection(db, "courses", courseId, "lessons"),
          orderBy("order", "asc"),
        );
        const snap = await getDocs(q);
        return { data: snap.docs.map((d) => ({ id: d.id, ...d.data() })) };
      },
      providesTags: (r, e, courseId) => [{ type: "Course", id: courseId }],
    }),
  }),
});

export const {
  useListCoursesQuery,
  useGetCoursesPageQuery,
  useGetCourseQuery,
  useCreateCourseMutation,
  useUpdateCourseMutation,
  useDeleteCourseMutation,
  useCountCoursesQuery,
  useListCategoriesQuery,
  useCreateCategoryMutation,
  useUpdateCategoryMutation,
  useDeleteCategoryMutation,
  useCountCategoriesQuery,
  useListEnrollmentsQuery,
  useJoinCourseMutation,
  useUnjoinCourseMutation,
  useUpdateProgressMutation,
  useListLessonsByCourseQuery,
} = firestoreApi;
