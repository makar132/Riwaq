import { auth, db } from "../../firebase";
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  updateProfile,
  signOut,
} from "firebase/auth";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { mapAuthError } from "./errors";

async function resolveEmail(identifier) {
  if (identifier.includes("@")) return identifier;
  const snap = await getDoc(doc(db, "usernames", identifier));
  if (!snap.exists()) {
    const err = new Error("Username not found");
    err.code = "auth/user-not-found";
    throw err;
  }
  return snap.data().email;
}

export async function login({ identifier, password }) {
  try {
    const email = await resolveEmail(identifier);
    await signInWithEmailAndPassword(auth, email, password);
    return { ok: true };
  } catch (e) {
    return { ok: false, error: mapAuthError(e, "login") };
  }
}

export async function signup({
  name,
  email,
  username,
  password,
  locale = "en",
}) {
  try {
    // simple username uniqueness check (client-side)
    const u = await getDoc(doc(db, "usernames", username));
    if (u.exists()) {
      return {
        ok: false,
        error: {
          code: "auth/username-taken",
          message: "Username is taken.",
          fieldErrors: { username: "Taken" },
        },
      };
    }

    const cred = await createUserWithEmailAndPassword(auth, email, password);
    await updateProfile(cred.user, { displayName: name });

    await setDoc(doc(db, "users", cred.user.uid), {
      email,
      name,
      isAdmin: false,
      preferences: { locale },
      wishlist: [],
      favourites: [],
    });
    await setDoc(doc(db, "usernames", username), { email, uid: cred.user.uid });

    return { ok: true };
  } catch (e) {
    return { ok: false, error: mapAuthError(e, "signup") };
  }
}

export async function resetPassword({ emailOrUsername }) {
  try {
    const email = await resolveEmail(emailOrUsername);
    await sendPasswordResetEmail(auth, email);
    return { ok: true };
  } catch (e) {
    return { ok: false, error: mapAuthError(e, "reset") };
  }
}

export async function logout() {
  try {
    await signOut(auth);
    return { ok: true };
  } catch (e) {
    return { ok: false, error: mapAuthError(e) };
  }
}
