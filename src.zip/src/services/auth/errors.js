export function mapAuthError(e, ctx = "generic") {
  const code = e?.code || "auth/unknown";
  const build = (message, fieldErrors = {}) => ({ code, message, fieldErrors });

  // Newer invalid-credentials codes (Firebase v9+)
  if (
    code === "auth/invalid-login-credentials" ||
    code === "auth/invalid-credential"
  ) {
    return build("Incorrect email/username or password.", {
      ...(ctx === "login"
        ? { identifier: "Check this", password: "Check this" }
        : {}),
    });
  }

  switch (code) {
    // Login
    case "auth/user-not-found":
      return build("No account found.", { identifier: "Not found" });
    case "auth/wrong-password":
      return build("Incorrect password.", { password: "Wrong password" });
    case "auth/user-disabled":
      return build("This account has been disabled.");
    case "auth/invalid-email":
      return build("Please enter a valid email.", { email: "Invalid email" });
    case "auth/too-many-requests":
      return build("Too many attempts. Please wait and try again.");
    case "auth/network-request-failed":
      return build("Network error. Check your connection.");

    // Signup
    case "auth/email-already-in-use":
      return build("This email is already in use.", {
        email: "Already in use",
      });
    case "auth/weak-password":
      return build("Password is too weak (min 6 characters).", {
        password: "Too weak",
      });
    case "auth/operation-not-allowed":
      return build("This sign-in method is not enabled.");

    case "auth/username-taken":
      return build("Username is taken.", { username: "Taken" });

    default:
      return build("Something went wrong. Please try again.");
  }
}
